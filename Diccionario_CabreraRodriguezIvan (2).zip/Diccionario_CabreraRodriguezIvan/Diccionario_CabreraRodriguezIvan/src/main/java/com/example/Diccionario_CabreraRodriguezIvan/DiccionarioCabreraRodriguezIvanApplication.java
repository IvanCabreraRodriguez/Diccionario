package com.example.Diccionario_CabreraRodriguezIvan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiccionarioCabreraRodriguezIvanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiccionarioCabreraRodriguezIvanApplication.class, args);
	}

}
