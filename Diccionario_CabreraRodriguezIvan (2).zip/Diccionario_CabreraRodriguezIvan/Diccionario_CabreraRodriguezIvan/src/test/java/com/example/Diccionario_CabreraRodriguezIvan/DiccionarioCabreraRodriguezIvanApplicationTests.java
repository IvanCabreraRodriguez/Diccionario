package com.example.Diccionario_CabreraRodriguezIvan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiccionarioCabreraRodriguezIvanApplicationTests {

	@Test
	void contextLoads() {
	}

}
