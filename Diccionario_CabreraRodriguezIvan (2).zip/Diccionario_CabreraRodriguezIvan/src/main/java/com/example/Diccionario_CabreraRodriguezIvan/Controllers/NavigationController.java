package com.example.Diccionario_CabreraRodriguezIvan.Controllers;

import com.example.Diccionario_CabreraRodriguezIvan.Services.TermService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class NavigationController {
    private final TermService termService;

    public NavigationController(TermService termService) {
        this.termService = termService;
    }

    @GetMapping("/login")
    public String login() {
        return "login"; // Busca src/main/resources/templates/login.html
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/terms")
    public String listTerms(Model model) {
        // Pasamos la lista de términos a la vista
        model.addAttribute("listaTerminos", termService.getAllTerms());
        return "terms_list"; // Busca src/main/resources/templates/terms_list.html
    }
}
