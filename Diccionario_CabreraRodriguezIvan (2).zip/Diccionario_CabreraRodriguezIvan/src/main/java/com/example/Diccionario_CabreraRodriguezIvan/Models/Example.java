package com.example.Diccionario_CabreraRodriguezIvan.Models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "examples")
public class Example {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El ejemplo en español no puede estar vacío")
    @Size(min = 5, max = 100, message = "Debe tener entre 5 y 100 caracteres")
    private String exEsp;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El ejemplo en inglés no puede estar vacío")
    @Size(min = 5, max = 100, message = "Debe tener entre 5 y 100 caracteres")
    private String exEng;

    @Column(nullable = true)
    private String author;

    @ManyToOne(optional = false)
    @JoinColumn(name = "term_id", nullable = false)
    private Term term;

    // --- CONSTRUCTORES ---

    // Constructor vacío (Obligatorio para Hibernate/JPA)
    public Example() {
    }

    // Constructor con parámetros (útil para crear objetos rápidamente)
    public Example(String exEsp, String exEng, String author, Term term) {
        this.exEsp = exEsp;
        this.exEng = exEng;
        this.author = author;
        this.term = term;
    }

    // --- GETTERS Y SETTERS ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExEsp() {
        return exEsp;
    }

    public void setExEsp(String exEsp) {
        this.exEsp = exEsp;
    }

    public String getExEng() {
        return exEng;
    }

    public void setExEng(String exEng) {
        this.exEng = exEng;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Term getTerm() {
        return term;
    }

    public void setTerm(Term term) {
        this.term = term;
    }
}