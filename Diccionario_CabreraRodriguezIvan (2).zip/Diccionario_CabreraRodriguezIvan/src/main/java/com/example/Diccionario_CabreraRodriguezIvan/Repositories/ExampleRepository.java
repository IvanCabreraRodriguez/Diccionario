package com.example.Diccionario_CabreraRodriguezIvan.Repositories;

import com.example.Diccionario_CabreraRodriguezIvan.Models.Example;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExampleRepository extends JpaRepository<Example, Integer> {

}