package com.example.Diccionario_CabreraRodriguezIvan.Repositories;

import com.example.Diccionario_CabreraRodriguezIvan.Models.Term;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TermRepository extends JpaRepository<Term, Integer> {

}