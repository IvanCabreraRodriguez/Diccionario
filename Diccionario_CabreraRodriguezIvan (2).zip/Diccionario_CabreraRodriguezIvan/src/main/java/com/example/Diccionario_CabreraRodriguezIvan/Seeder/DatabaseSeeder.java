package com.example.Diccionario_CabreraRodriguezIvan.Seeder;

import com.example.Diccionario_CabreraRodriguezIvan.Models.Role;
import com.example.Diccionario_CabreraRodriguezIvan.Models.User;
import com.example.Diccionario_CabreraRodriguezIvan.Repositories.RoleRepository;
import com.example.Diccionario_CabreraRodriguezIvan.Repositories.TermRepository;
import com.example.Diccionario_CabreraRodriguezIvan.Repositories.UserRepository;
import com.example.Diccionario_CabreraRodriguezIvan.Services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class DatabaseSeeder implements CommandLineRunner {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserService userService;

    public DatabaseSeeder(UserRepository userRepository, RoleRepository roleRepository, UserService userService) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.userService = userService;
    }
    @Override
    public void run(String... args) throws Exception {
        //Crear Roles si no existen
        Role basicRole = createRoleIfNotFound(Role.RoleName.BASIC);
        Role adminRole = createRoleIfNotFound(Role.RoleName.ADMIN);
        Role premiumRole = createRoleIfNotFound(Role.RoleName.PREMIUM);

        //Crear Usuarios por defecto
        //Usuario Basic
        if (!userRepository.existsByNickname(("BASIC"))) {
            User basicUser = new User("BASIC", "Basic123!","basic@diccionario.com", "España");
            basicUser.setRoles(Set.of(basicRole));
            userService.createUser(basicUser);// Usamos el servicio para que encripte la clave
        }
        //Usuario Admin
        if (!userRepository.existsByNickname(("ADMIN"))) {
            User adminUser = new User("ADMIN", "Admin123!","admin@diccionario.com", "España");
            adminUser.setRoles(Set.of(adminRole));
            userService.createUser(adminUser);
        }
        //Usuario Premium
        if (!userRepository.existsByNickname(("PREMIUM"))) {
            User premiumUser = new User("PREMIUM", "Premium123!","premium@diccionario.com", "España");
            premiumUser.setRoles(Set.of(premiumRole));
            userService.createUser(premiumUser);
        }
        System.out.println("--> Seeder ejecutado: Roles y Usuarios base verificados/creados");
    }
    private Role createRoleIfNotFound(Role.RoleName name) {
        return roleRepository.findByName(name)
                .orElseGet(() -> roleRepository.save(new Role(name)));
    }
}
