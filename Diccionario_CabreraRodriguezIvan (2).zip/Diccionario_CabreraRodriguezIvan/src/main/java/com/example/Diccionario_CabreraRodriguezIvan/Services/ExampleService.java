package com.example.Diccionario_CabreraRodriguezIvan.Services;

import org.springframework.stereotype.Service;

@Service
public class ExampleService {
}
