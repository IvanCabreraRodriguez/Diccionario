package com.example.Diccionario_CabreraRodriguezIvan.Services;

import com.example.Diccionario_CabreraRodriguezIvan.Models.Term;
import com.example.Diccionario_CabreraRodriguezIvan.Repositories.TermRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TermService {
    private final TermRepository termRepository;

    public TermService(TermRepository termRepository) {
        this.termRepository = termRepository;
    }

    public List<Term> getAllTerms() {
        return termRepository
                .findAll(PageRequest.of(0, 30, Sort.by("id").ascending()))
                .getContent();
    }


}
