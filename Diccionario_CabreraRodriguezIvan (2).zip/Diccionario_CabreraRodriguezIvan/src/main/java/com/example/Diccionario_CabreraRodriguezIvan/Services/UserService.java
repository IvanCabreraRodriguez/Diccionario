package com.example.Diccionario_CabreraRodriguezIvan.Services;

import com.example.Diccionario_CabreraRodriguezIvan.Models.User;
import com.example.Diccionario_CabreraRodriguezIvan.Repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService implements UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // --- 1. CREACIÓN DE NUEVO USUARIO ---
    @Transactional
    public User createUser(User user) {
        // Hasheamos la contraseña con BCrypt antes de guardar
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    // --- 2. IMPLEMENTACIÓN DE USERDETAILS_SERVICE (Para Login) ---
    @Override
    public UserDetails loadUserByUsername(String nickName) throws UsernameNotFoundException {
        User user = userRepository.findByNickname(nickName)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + nickName));

        // Mapeamos tus roles a la estructura que entiende Spring Security
        return new org.springframework.security.core.userdetails.User(
                user.getNickName(),
                user.getPassword(),
                user.getRoles().stream()
                        .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName().name()))
                        .collect(Collectors.toList())
        );
    }

    // --- MÉTODOS GENERALES ---
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public void deleteUser(String nickName){
        User user = userRepository.findByNickname(nickName)
                .orElseThrow(() -> new RuntimeException("User not found"));
        userRepository.delete(user);
    }
}
